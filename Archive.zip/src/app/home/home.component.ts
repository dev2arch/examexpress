import { Component, OnInit } from '@angular/core';

import { AllTestService } from '../services/all-test.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  testData;

  constructor(private allTest: AllTestService) { }

  ngOnInit() {
    window.scrollTo(0, 0); 
    // this.allTest.getAllTests()
    this.allTest.getAllTests()
    .subscribe(
      (data)=>(this.testData = data, console.log(data)),
      (error)=>(console.log(error))
    )
  }

}
