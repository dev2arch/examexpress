export class AppConfig {
  public static API_ENDPOINT= 'http://13.126.208.177:8080' ;
}
