import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-exams',
  templateUrl: './student-exams.component.html',
  styleUrls: ['./student-exams.component.css']
})
export class StudentExamsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
