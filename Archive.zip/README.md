# ng2-quiz
A general purpose quiz application developed in angular 2 that can be used for multiple purpose.

For detailed documentation, please go to: https://www.codeproject.com/Articles/1167451/Quiz-Application-in-Angular
